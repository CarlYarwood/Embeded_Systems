/* Carl Yarwood
   delay.h
*/

void delay1us ( unsigned n );

void delay1ms ( unsigned n );
